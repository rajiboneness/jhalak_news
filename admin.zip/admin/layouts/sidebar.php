<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
    <ul class="app-menu">
        <li>
            <a class="app-menu__item" href="index.php">
                <span class="app-menu__label">Dashboard</span>
            </a>
        </li>
        <li>
            <a class="app-menu__item"
                href="news-upload.php">
                <span class="app-menu__label">Upload News</span>
            </a>
        </li>

        <!-- <li class="treeview">
            <a class="app-menu__item" href="#" data-toggle="treeview">
                <span class="app-menu__label">Course Management</span>
                <i class="treeview-indicator fa fa-angle-right"></i>
            </a>
            <ul class="treeview-menu">
                <li style="padding-left: 20px;">
                    <a class="treeview-item" href="#">Categories</a>
                </li>
                <li style="padding-left: 20px;">
                    <a class="treeview-item" href="#">Categories</a>
                </li>
                <li style="padding-left: 20px;">
                    <a class="treeview-item" href="#">Categories</a>
                </li>
                
            </ul>
        </li> -->
       
    </ul>
</aside>